1) Get Kira from here: https://gitlab.com/kira-pyred/kira

2) After installation simply run: 
    kira jobs.yaml
